package br.com.mobila.splunkinmyharley;

/**
 * Created by lsaganski on 05/09/17.
 */

public class SplunkMessage {
    public String time;
    public String host;
    public String source;
    public String sourceType;
    public SplunkEvent event;

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public SplunkEvent getEvent() {
        return event;
    }

    public void setEvent(SplunkEvent event) {
        this.event = event;
    }
}

class SplunkEvent {
    public String parser;
    public String parserVersion;
    public int Speed;
    public int RPM;
    public double Latitude;
    public double Longitude;
    public int Gear;
    public boolean Neutral;
    public String VIN;
    public int Odometer;
    public String TurnSignal;
    public int FuelGauge;
    public int FuelConsumption;
    public boolean CheckEngine;

    public String getParser() {
        return parser;
    }

    public void setParser(String parser) {
        this.parser = parser;
    }

    public String getParserVersion() {
        return parserVersion;
    }

    public void setParserVersion(String parserVersion) {
        this.parserVersion = parserVersion;
    }

    public int getSpeed() {
        return Speed;
    }

    public void setSpeed(int speed) {
        Speed = speed;
    }

    public int getRPM() {
        return RPM;
    }

    public void setRPM(int RPM) {
        this.RPM = RPM;
    }

    public double getLatitude() {
        return Latitude;
    }

    public void setLatitude(double latitude) {
        Latitude = latitude;
    }

    public double getLongitude() {
        return Longitude;
    }

    public void setLongitude(double longitude) {
        Longitude = longitude;
    }

    public int isGear() {
        return Gear;
    }

    public void setGear(int gear) {
        Gear = gear;
    }

    public boolean getNeutral() {
        return Neutral;
    }

    public void setNeutral(boolean neutral) {
        Neutral = neutral;
    }

    public String getVIN() {
        return VIN;
    }

    public void setVIN(String VIN) {
        this.VIN = VIN;
    }

    public int isOdometer() {
        return Odometer;
    }

    public void setOdometer(int odometer) {
        Odometer = odometer;
    }

    public String getTurnSignal() {
        return TurnSignal;
    }

    public void setTurnSignal(String turnSignal) {
        TurnSignal = turnSignal;
    }

    public int isFuelGauge() {
        return FuelGauge;
    }

    public void setFuelGauge(int fuelGauge) {
        FuelGauge = fuelGauge;
    }

    public int getFuelConsumption() {
        return FuelConsumption;
    }

    public void setFuelConsumption(int fuelConsumption) {
        FuelConsumption = fuelConsumption;
    }

    public boolean isCheckEngine() {
        return CheckEngine;
    }

    public void setCheckEngine(boolean checkEngine) {
        CheckEngine = checkEngine;
    }
}
