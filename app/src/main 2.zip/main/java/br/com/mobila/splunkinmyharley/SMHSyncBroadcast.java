package br.com.mobila.splunkinmyharley;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;

/**
 * Created by leonardo.saganski on 10/01/17.
 */

public class SMHSyncBroadcast extends BroadcastReceiver {

    public static final int REQUEST_CODE = 12345;
    public static final String ACTION = "splunkin.my.harley.BACKUP_WAYPOINTS";

    @Override
    public void onReceive(Context context, Intent intent) {
        Send();
    }

    private void Send() {

        SplunkMessage msg = new SplunkMessage();
        SplunkEvent ev = new SplunkEvent();
        ev.setSpeed(Holder.shared().STORED_SPEED_IMPERIAL);
        ev.setRPM(Holder.shared().STORED_RPM);
        ev.setLatitude(Holder.shared().STORED_LATITUDE);
        ev.setLongitude(Holder.shared().STORED_LONGITUDE);
        ev.setGear(Holder.shared().STORED_GEAR);
        ev.setNeutral(Holder.shared().STORED_NEUTRAL);
        ev.setVIN(Holder.shared().STORED_VIN);
        ev.setOdometer(Holder.shared().STORED_ODOMETER_IMPERIAL);
        ev.setTurnSignal(Holder.shared().STORED_TURNSIGNALS == 1 ? "Right" : "Left");
        ev.setCheckEngine(Holder.shared().STORED_CHECKENGINE);
        ev.setFuelGauge(Holder.shared().STORED_FUELGAUGE);
        ev.setFuelConsumption(Holder.shared().STORED_FUEL_AVERAGE_IMPERIAL);

        msg.setHost(Holder.shared().STORED_VIN);
        msg.event = ev;

        String obj = new Gson().toJson(msg);

        SMHApi.shared().SendToSplunk(obj);
    }
}
