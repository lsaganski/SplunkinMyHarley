//
// HarleyDroid: Harley Davidson J1850 Data Analyser for Android.
//
// Copyright (C) 2010-2012 Stelian Pop <stelian@popies.net>
//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program.  If not, see <http://www.gnu.org/licenses/>.
//

package br.com.mobila.splunkinmyharley;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.preference.PreferenceActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;

import com.google.gson.Gson;


public class HarleyDroidDashboard extends HarleyDroid {
	private static final boolean D = false;
	private static final String TAG = HarleyDroidDashboard.class.getSimpleName();

	private Toolbar mToolbar;
	public  ImageButton btnPlay;
	public  ImageButton btnPrefs;
	public  ImageButton btnSend;

	private HarleyDroidDashboardView mHarleyDroidDashboardView;
	private int mViewMode = HarleyDroidDashboardView.VIEW_GRAPHIC;

	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		if (D) Log.d(TAG, "onCreate()");
		super.onCreate(savedInstanceState);

		mHarleyDroidDashboardView = new HarleyDroidDashboardView(this);
		mHarleyDroidDashboardView.changeView(mViewMode, getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT, mUnitMetric);

		setUpToolbar();
	}

	@Override
	public void onStart() {
		if (D) Log.d(TAG, "onStart()");
		super.onStart();

		mViewMode = mPrefs.getInt("dashboardviewmode", HarleyDroidDashboardView.VIEW_TEXT);
	/*	mHarleyDroidDashboardView.changeView(mViewMode,
				mOrientation == ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED ? getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT
																			: mOrientation == ActivityInfo.SCREEN_ORIENTATION_PORTRAIT ? true : false,
				mUnitMetric);*/
		mHarleyDroidDashboardView.drawAll(mHD);
	}

	@Override
	public void onStop() {
		if (D) Log.d(TAG, "onStop()");
		super.onStop();

		SharedPreferences.Editor editor = mPrefs.edit();
		editor.putInt("dashboardviewmode", mViewMode);
		editor.commit();
	}

/*	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		if (D) Log.d(TAG, "onConfigurationChanged()");
		super.onConfigurationChanged(newConfig);

		if (mOrientation == ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED) {
			mHarleyDroidDashboardView.changeView(mViewMode, newConfig.orientation == Configuration.ORIENTATION_PORTRAIT, mUnitMetric);
			mHarleyDroidDashboardView.drawAll(mHD);
		}
	}*/

	private void setUpToolbar() {
		mToolbar = (Toolbar) findViewById(R.id.toolbar);
		if (mToolbar != null) {
			setSupportActionBar(mToolbar);
			getSupportActionBar().setDisplayShowTitleEnabled(false);

			btnPlay = mToolbar.findViewById(R.id.btnPlay);
			btnPrefs = mToolbar.findViewById(R.id.btnPrefs);
			btnSend = mToolbar.findViewById(R.id.btnSend);

			btnPlay.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {
					if (mService == null) {
						startHDS();
						SMHLocation.shared().startLocation();

						Holder.shared().setupAlarm();
					} else {
						stopHDS();
						SMHLocation.shared().stopService();
						SMHLocation.shared().stopLocation();
					}
				}
			});

			btnPrefs.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {

					Intent settingsActivity = new Intent(getBaseContext(), HarleyDroidSettings.class);
					if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
						settingsActivity.putExtra(PreferenceActivity.EXTRA_SHOW_FRAGMENT, HarleyDroidSettings.Fragment.class.getName());
						settingsActivity.putExtra(PreferenceActivity.EXTRA_NO_HEADERS, true);
					}
					startActivity(settingsActivity);
				}
			});

			btnSend.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View view) {

					SplunkMessage msg = new SplunkMessage();
					SplunkEvent ev = new SplunkEvent();
					ev.setParser("SMH Android App");
					ev.setParserVersion("0.1");
					ev.setSpeed(Holder.shared().STORED_SPEED_IMPERIAL);
					ev.setRPM(Holder.shared().STORED_RPM);
					ev.setLatitude(Holder.shared().STORED_LATITUDE);
					ev.setLongitude(Holder.shared().STORED_LONGITUDE);
					ev.setGear(Holder.shared().STORED_GEAR);
					ev.setNeutral(Holder.shared().STORED_NEUTRAL);
					ev.setVIN(Holder.shared().STORED_VIN);
					ev.setOdometer(Holder.shared().STORED_ODOMETER_IMPERIAL);
					ev.setTurnSignal(Holder.shared().STORED_TURNSIGNALS == 1 ? "Right" : "Left");
					ev.setCheckEngine(Holder.shared().STORED_CHECKENGINE);
					ev.setFuelGauge(Holder.shared().STORED_FUELGAUGE);
					ev.setFuelConsumption(Holder.shared().STORED_FUEL_AVERAGE_IMPERIAL);

					msg.setTime("");
					msg.setSource("OBDII Bluetooth");
					msg.setSourceType("SMHdata");
					msg.setHost(Holder.shared().STORED_VIN);
					msg.setEvent(ev);

					String obj = new Gson().toJson(msg);

					SMHApi.shared().SendToSplunk(obj);
				}
			});

		}
	}

	public void onServiceConnected(ComponentName name, IBinder service) {
		if (D) Log.d(TAG, "onServiceConnected()");
		super.onServiceConnected(name, service);

		if (!mService.isPolling())
			mService.startPoll();

		mHD.addHarleyDataDashboardListener(mHarleyDroidDashboardView);
		mHarleyDroidDashboardView.drawAll(mHD);
	}

	public void onServiceDisconnected(ComponentName name) {
		if (D) Log.d(TAG, "onServiceDisconnected()");

		mHD.removeHarleyDataDashboardListener(mHarleyDroidDashboardView);
		mHarleyDroidDashboardView.drawAll(null);
		super.onServiceDisconnected(name);
	}
}
