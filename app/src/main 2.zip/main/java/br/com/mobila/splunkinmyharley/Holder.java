package br.com.mobila.splunkinmyharley;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

/**
 * Created by lsaganski on 05/09/17.
 */

public class Holder {

    private static Holder instance;

    public int STORED_RPM;
    public int STORED_SPEED_IMPERIAL;
    public int STORED_SPEED_METRIC;
    public int STORED_ENGINETEMP_IMPERIAL;
    public int STORED_ENGINETEMP_METRIC;
    public int STORED_FUELGAUGE;
    public boolean STORED_LOW_FUEL;
    public int STORED_TURNSIGNALS;
    public boolean STORED_NEUTRAL;
    public boolean STORED_CLUTCH;
    public int STORED_GEAR;
    public boolean STORED_CHECKENGINE;
    public int STORED_ODOMETER_IMPERIAL;
    public int STORED_ODOMETER_METRIC;
    public int STORED_FUEL_IMPERIAL;
    public int STORED_FUEL_METRIC;
    public int STORED_FUEL_AVERAGE_IMPERIAL;
    public int STORED_FUEL_AVERAGE_METRIC;
    public int STORED_FUEL_INSTANT_IMPERIAL;
    public int STORED_FUEL_INSTANT_METRIC;
    public String STORED_VIN;
    public double STORED_LATITUDE;
    public double STORED_LONGITUDE;

    public Context context;

    public static Holder shared() {
        if (instance == null)
            instance = new Holder();

        return instance;
    }

    public void reset() {
        instance = new Holder();
    }

    public void setupAlarm() {
        cancelAlarm();
        Intent intent = new Intent(SMHSyncBroadcast.ACTION);
        // Create a PendingIntent to be triggered when the alarm goes off
        final PendingIntent pIntent = PendingIntent.getBroadcast(context, SMHSyncBroadcast.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        // Setup periodic alarm every 5 seconds
        AlarmManager alarm = (AlarmManager) ((HarleyDroid) context).getSystemService(Context.ALARM_SERVICE);
        // First parameter is the type: ELAPSED_REALTIME, ELAPSED_REALTIME_WAKEUP, RTC_WAKEUP
        // Interval can be INTERVAL_FIFTEEN_MINUTES, INTERVAL_HALF_HOUR, INTERVAL_HOUR, INTERVAL_DAY

        long interval = 5000;
        alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, getNextTime(),
                interval, pIntent);    // AlarmManager.INTERVAL_FIFTEEN_MINUTES
    }

    public void cancelAlarm() {
        Intent intent = new Intent(((HarleyDroid) context).getApplicationContext(), SMHSyncBroadcast.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(context, SMHSyncBroadcast.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) ((HarleyDroid) context).getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    private long getNextTime() {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(System.currentTimeMillis());
        c.add(Calendar.SECOND, 5);
        long time = c.getTimeInMillis();
        return time;
    }
}
